/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Time spent sending/waiting for the response of a request to the token endpoint
 */
const NetworkClientSendPostRequestAsync = "networkClientSendPostRequestAsync";
const RefreshTokenClientExecutePostToTokenEndpoint = "refreshTokenClientExecutePostToTokenEndpoint";
const AuthorizationCodeClientExecutePostToTokenEndpoint = "authorizationCodeClientExecutePostToTokenEndpoint";
/**
 * Time spent on the network for refresh token acquisition
 */
const RefreshTokenClientExecuteTokenRequest = "refreshTokenClientExecuteTokenRequest";
/**
 * Time taken for acquiring refresh token , records RT size
 */
const RefreshTokenClientAcquireToken = "refreshTokenClientAcquireToken";
/**
 * Time taken for acquiring cached refresh token
 */
const RefreshTokenClientAcquireTokenWithCachedRefreshToken = "refreshTokenClientAcquireTokenWithCachedRefreshToken";
/**
 * Helper function to create token request body in RefreshTokenClient (msal-common).
 */
const RefreshTokenClientCreateTokenRequestBody = "refreshTokenClientCreateTokenRequestBody";
const SilentFlowClientGenerateResultFromCacheRecord = "silentFlowClientGenerateResultFromCacheRecord";
/**
 * getAuthCodeUrl API (msal-browser and msal-node).
 */
const GetAuthCodeUrl = "getAuthCodeUrl";
/**
 * Functions from InteractionHandler (msal-browser)
 */
const HandleCodeResponseFromServer = "handleCodeResponseFromServer";
/**
 * APIs in Authorization Code Client (msal-common)
 */
const AuthClientExecuteTokenRequest = "authClientExecuteTokenRequest";
const AuthClientCreateTokenRequestBody = "authClientCreateTokenRequestBody";
const UpdateTokenEndpointAuthority = "updateTokenEndpointAuthority";
/**
 * Generate functions in PopTokenGenerator (msal-common)
 */
const PopTokenGenerateCnf = "popTokenGenerateCnf";
/**
 * handleServerTokenResponse API in ResponseHandler (msal-common)
 */
const HandleServerTokenResponse = "handleServerTokenResponse";
/**
 * Authority functions
 */
const AuthorityResolveEndpointsAsync = "authorityResolveEndpointsAsync";
const AuthorityGetCloudDiscoveryMetadataFromNetwork = "authorityGetCloudDiscoveryMetadataFromNetwork";
const AuthorityUpdateCloudDiscoveryMetadata = "authorityUpdateCloudDiscoveryMetadata";
const AuthorityGetEndpointMetadataFromNetwork = "authorityGetEndpointMetadataFromNetwork";
const AuthorityUpdateEndpointMetadata = "authorityUpdateEndpointMetadata";
const AuthorityUpdateMetadataWithRegionalInformation = "authorityUpdateMetadataWithRegionalInformation";
/**
 * Region Discovery functions
 */
const RegionDiscoveryDetectRegion = "regionDiscoveryDetectRegion";
const RegionDiscoveryGetRegionFromIMDS = "regionDiscoveryGetRegionFromIMDS";
const RegionDiscoveryGetCurrentVersion = "regionDiscoveryGetCurrentVersion";
/**
 * Cache operations
 */
const CacheManagerGetRefreshToken = "cacheManagerGetRefreshToken";
const SetUserData = "setUserData";

export { AuthClientCreateTokenRequestBody, AuthClientExecuteTokenRequest, AuthorityGetCloudDiscoveryMetadataFromNetwork, AuthorityGetEndpointMetadataFromNetwork, AuthorityResolveEndpointsAsync, AuthorityUpdateCloudDiscoveryMetadata, AuthorityUpdateEndpointMetadata, AuthorityUpdateMetadataWithRegionalInformation, AuthorizationCodeClientExecutePostToTokenEndpoint, CacheManagerGetRefreshToken, GetAuthCodeUrl, HandleCodeResponseFromServer, HandleServerTokenResponse, NetworkClientSendPostRequestAsync, PopTokenGenerateCnf, RefreshTokenClientAcquireToken, RefreshTokenClientAcquireTokenWithCachedRefreshToken, RefreshTokenClientCreateTokenRequestBody, RefreshTokenClientExecutePostToTokenEndpoint, RefreshTokenClientExecuteTokenRequest, RegionDiscoveryDetectRegion, RegionDiscoveryGetCurrentVersion, RegionDiscoveryGetRegionFromIMDS, SetUserData, SilentFlowClientGenerateResultFromCacheRecord, UpdateTokenEndpointAuthority };
//# sourceMappingURL=PerformanceEvents.mjs.map
