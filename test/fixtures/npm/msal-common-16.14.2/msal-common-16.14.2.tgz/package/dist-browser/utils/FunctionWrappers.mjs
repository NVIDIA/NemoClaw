/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Wraps a function with a performance measurement.
 * Usage: invoke(functionToCall, performanceClient, "EventName", "correlationId")(...argsToPassToFunction)
 * @param callback
 * @param eventName
 * @param logger
 * @param telemetryClient
 * @param correlationId
 * @returns
 * @internal
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const invoke = (callback, eventName, logger, telemetryClient, correlationId) => {
    return (...args) => {
        logger.trace(`1plfzx ${eventName}`, correlationId);
        const inProgressEvent = telemetryClient.startMeasurement(eventName, correlationId);
        if (correlationId) {
            // Track number of times this API is called in a single request
            telemetryClient.incrementFields({ [`ext.${eventName}CallCount`]: 1 }, correlationId);
        }
        try {
            const result = callback(...args);
            inProgressEvent.end({
                success: true,
            });
            logger.trace(`1g8n6a ${eventName}`, correlationId);
            return result;
        }
        catch (e) {
            logger.trace(`0cfd8i ${eventName}`, correlationId);
            try {
                logger.trace(JSON.stringify(e), correlationId);
            }
            catch (e) {
                logger.trace("00dty7", correlationId);
            }
            inProgressEvent.end({
                success: false,
            }, e);
            throw e;
        }
    };
};
/**
 * Wraps an async function with a performance measurement.
 * Usage: invokeAsync(functionToCall, performanceClient, "EventName", "correlationId")(...argsToPassToFunction)
 * @param callback
 * @param eventName
 * @param logger
 * @param telemetryClient
 * @param correlationId
 * @returns
 * @internal
 *
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const invokeAsync = (callback, eventName, logger, telemetryClient, correlationId) => {
    return (...args) => {
        logger.trace(`1plfzx ${eventName}`, correlationId);
        const inProgressEvent = telemetryClient.startMeasurement(eventName, correlationId);
        if (correlationId) {
            // Track number of times this API is called in a single request
            telemetryClient.incrementFields({ [`ext.${eventName}CallCount`]: 1 }, correlationId);
        }
        return callback(...args)
            .then((response) => {
            logger.trace(`1g8n6a ${eventName}`, correlationId);
            inProgressEvent.end({
                success: true,
            });
            return response;
        })
            .catch((e) => {
            logger.trace(`0cfd8i ${eventName}`, correlationId);
            try {
                logger.trace(JSON.stringify(e), correlationId);
            }
            catch (e) {
                logger.trace("00dty7", correlationId);
            }
            inProgressEvent.end({
                success: false,
            }, e);
            throw e;
        });
    };
};

export { invoke, invokeAsync };
//# sourceMappingURL=FunctionWrappers.mjs.map
