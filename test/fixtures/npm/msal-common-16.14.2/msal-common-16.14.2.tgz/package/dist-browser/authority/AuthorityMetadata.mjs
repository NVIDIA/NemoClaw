/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
import { UrlString } from '../url/UrlString.mjs';
import { AuthorityMetadataSource } from '../utils/Constants.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
// Build endpoint metadata dynamically to avoid string duplication
const endpointHosts = [
    { host: "login.microsoftonline.com" },
    { host: "login.partner.microsoftonline.cn" },
    { host: "login.microsoftonline.us" },
    { host: "login.sovcloud-identity.fr" },
    { host: "login.sovcloud-identity.de" },
    { host: "login.sovcloud-identity.sg" },
];
function buildOpenIdConfig(host, issuerHost) {
    return {
        token_endpoint: `https://${host}/{tenantid}/oauth2/v2.0/token`,
        jwks_uri: `https://${host}/{tenantid}/discovery/v2.0/keys`,
        issuer: `https://${issuerHost}/{tenantid}/v2.0`,
        authorization_endpoint: `https://${host}/{tenantid}/oauth2/v2.0/authorize`,
        end_session_endpoint: `https://${host}/{tenantid}/oauth2/v2.0/logout`,
    };
}
const dynamicEndpointMetadata = endpointHosts.reduce((acc, { host, issuerHost }) => {
    acc[host] = buildOpenIdConfig(host, issuerHost || host);
    return acc;
}, {});
const rawMetdataJSON = {
    endpointMetadata: dynamicEndpointMetadata,
    instanceDiscoveryMetadata: {
        metadata: [
            {
                preferred_network: "login.microsoftonline.com",
                preferred_cache: "login.windows.net",
                aliases: [
                    "login.microsoftonline.com",
                    "login.windows.net",
                    "login.microsoft.com",
                    "sts.windows.net",
                ],
            },
            {
                preferred_network: "login.partner.microsoftonline.cn",
                preferred_cache: "login.partner.microsoftonline.cn",
                aliases: [
                    "login.partner.microsoftonline.cn",
                    "login.chinacloudapi.cn",
                ],
            },
            {
                preferred_network: "login.microsoftonline.de",
                preferred_cache: "login.microsoftonline.de",
                aliases: ["login.microsoftonline.de"],
            },
            {
                preferred_network: "login.microsoftonline.us",
                preferred_cache: "login.microsoftonline.us",
                aliases: [
                    "login.microsoftonline.us",
                    "login.usgovcloudapi.net",
                ],
            },
            {
                preferred_network: "login-us.microsoftonline.com",
                preferred_cache: "login-us.microsoftonline.com",
                aliases: ["login-us.microsoftonline.com"],
            },
            {
                preferred_network: "login.sovcloud-identity.fr",
                preferred_cache: "login.sovcloud-identity.fr",
                aliases: ["login.sovcloud-identity.fr"],
            },
            {
                preferred_network: "login.sovcloud-identity.de",
                preferred_cache: "login.sovcloud-identity.de",
                aliases: ["login.sovcloud-identity.de"],
            },
            {
                preferred_network: "login.sovcloud-identity.sg",
                preferred_cache: "login.sovcloud-identity.sg",
                aliases: ["login.sovcloud-identity.sg"],
            },
        ],
    },
};
const EndpointMetadata = rawMetdataJSON.endpointMetadata;
const InstanceDiscoveryMetadata = rawMetdataJSON.instanceDiscoveryMetadata;
const InstanceDiscoveryMetadataAliases = new Set();
InstanceDiscoveryMetadata.metadata.forEach((metadataEntry) => {
    metadataEntry.aliases.forEach((alias) => {
        InstanceDiscoveryMetadataAliases.add(alias);
    });
});
/**
 * Attempts to get an aliases array from the static authority metadata sources based on the canonical authority host
 * @param staticAuthorityOptions
 * @param logger
 * @returns
 */
function getAliasesFromStaticSources(staticAuthorityOptions, logger, correlationId) {
    let staticAliases;
    const canonicalAuthority = staticAuthorityOptions.canonicalAuthority;
    if (canonicalAuthority) {
        const authorityHost = new UrlString(canonicalAuthority, correlationId).getUrlComponents().HostNameAndPort;
        staticAliases =
            getAliasesFromMetadata(logger, correlationId, authorityHost, staticAuthorityOptions.cloudDiscoveryMetadata?.metadata, AuthorityMetadataSource.CONFIG) ||
                getAliasesFromMetadata(logger, correlationId, authorityHost, InstanceDiscoveryMetadata.metadata, AuthorityMetadataSource.HARDCODED_VALUES) ||
                staticAuthorityOptions.knownAuthorities;
    }
    return staticAliases || [];
}
/**
 * Returns aliases for from the raw cloud discovery metadata passed in
 * @param authorityHost
 * @param rawCloudDiscoveryMetadata
 * @returns
 */
function getAliasesFromMetadata(logger, correlationId, authorityHost, cloudDiscoveryMetadata, source) {
    logger.trace(`1bmquz ${source}`, correlationId);
    if (authorityHost && cloudDiscoveryMetadata) {
        const metadata = getCloudDiscoveryMetadataFromNetworkResponse(cloudDiscoveryMetadata, authorityHost);
        if (metadata) {
            logger.trace(`1fotbt ${source}`, correlationId);
            return metadata.aliases;
        }
        else {
            logger.trace(`14avvj ${source}`, correlationId);
        }
    }
    return null;
}
/**
 * Get cloud discovery metadata for common authorities
 */
function getCloudDiscoveryMetadataFromHardcodedValues(authorityHost) {
    const metadata = getCloudDiscoveryMetadataFromNetworkResponse(InstanceDiscoveryMetadata.metadata, authorityHost);
    return metadata;
}
/**
 * Searches instance discovery network response for the entry that contains the host in the aliases list
 * @param response
 * @param authority
 */
function getCloudDiscoveryMetadataFromNetworkResponse(response, authorityHost) {
    for (let i = 0; i < response.length; i++) {
        const metadata = response[i];
        if (metadata.aliases.includes(authorityHost)) {
            return metadata;
        }
    }
    return null;
}

export { EndpointMetadata, InstanceDiscoveryMetadata, InstanceDiscoveryMetadataAliases, getAliasesFromMetadata, getAliasesFromStaticSources, getCloudDiscoveryMetadataFromHardcodedValues, getCloudDiscoveryMetadataFromNetworkResponse, rawMetdataJSON };
//# sourceMappingURL=AuthorityMetadata.mjs.map
