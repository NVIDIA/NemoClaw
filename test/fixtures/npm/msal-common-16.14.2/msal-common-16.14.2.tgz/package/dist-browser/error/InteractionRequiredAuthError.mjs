/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
import { AuthError } from './AuthError.mjs';
import { interactionRequired, consentRequired, loginRequired, badToken, uiNotAllowed, interruptedUser } from './InteractionRequiredAuthErrorCodes.mjs';
import * as InteractionRequiredAuthErrorCodes from './InteractionRequiredAuthErrorCodes.mjs';
export { InteractionRequiredAuthErrorCodes };

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * InteractionRequiredServerErrorMessage contains string constants used by error codes and messages returned by the server indicating interaction is required
 */
const InteractionRequiredServerErrorMessage = [
    interactionRequired,
    consentRequired,
    loginRequired,
    badToken,
    uiNotAllowed,
    interruptedUser,
];
const InteractionRequiredAuthSubErrorMessage = [
    "message_only",
    "additional_action",
    "basic_action",
    "user_password_expired",
    "consent_required",
    "bad_token",
    "ui_not_allowed",
    "interrupted_user",
];
/**
 * Error thrown when user interaction is required.
 */
class InteractionRequiredAuthError extends AuthError {
    constructor(errorCode, correlationId, errorMessage, subError, timestamp, traceId, claims, errorNo) {
        super(errorCode, correlationId, errorMessage, subError);
        Object.setPrototypeOf(this, InteractionRequiredAuthError.prototype);
        this.timestamp = timestamp || "";
        this.traceId = traceId || "";
        this.claims = claims || "";
        this.name = "InteractionRequiredAuthError";
        this.errorNo = errorNo;
    }
}
/**
 * Helper function used to determine if an error thrown by the server requires interaction to resolve
 * @param errorCode
 * @param errorString
 * @param subError
 */
function isInteractionRequiredError(errorCode, errorString, subError) {
    const isInteractionRequiredErrorCode = !!errorCode &&
        InteractionRequiredServerErrorMessage.indexOf(errorCode) > -1;
    const isInteractionRequiredSubError = !!subError &&
        InteractionRequiredAuthSubErrorMessage.indexOf(subError) > -1;
    const isInteractionRequiredErrorDesc = !!errorString &&
        InteractionRequiredServerErrorMessage.some((irErrorCode) => {
            return errorString.indexOf(irErrorCode) > -1;
        });
    return (isInteractionRequiredErrorCode ||
        isInteractionRequiredErrorDesc ||
        isInteractionRequiredSubError);
}
/**
 * Creates an InteractionRequiredAuthError
 */
function createInteractionRequiredAuthError(errorCode, correlationId, errorMessage) {
    return new InteractionRequiredAuthError(errorCode, correlationId, errorMessage);
}

export { InteractionRequiredAuthError, InteractionRequiredAuthSubErrorMessage, InteractionRequiredServerErrorMessage, createInteractionRequiredAuthError, isInteractionRequiredError };
//# sourceMappingURL=InteractionRequiredAuthError.mjs.map
