/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
/* eslint-disable header/header */
const name = "@azure/msal-common";
const version = "16.14.2";

export { name, version };
//# sourceMappingURL=packageMetadata.mjs.map
