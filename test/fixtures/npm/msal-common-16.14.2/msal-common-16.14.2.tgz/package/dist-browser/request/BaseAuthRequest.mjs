/*! @azure/msal-common v16.14.2 2026-10-02 */
'use strict';
import { createClientAuthError } from '../error/ClientAuthError.mjs';
import { misplacedResourceParam, resourceParameterRequired } from '../error/ClientAuthErrorCodes.mjs';

/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * Helper to enforce resource parameter presence in token requests when isMcp is set in the configuration.
 * If resource parameter is set in both the request and in extraQueryParameters or extraParameters, an error will be thrown.
 * This is used for MCP flows.
 * @param isMcp - Flag indicating if application is an MCP app, from configuration
 * @param request - Auth request
 */
function enforceResourceParameter(isMcp, request) {
    if (!isMcp) {
        return;
    }
    if (request.resource &&
        (containsResourceParam(request.extraParameters) ||
            containsResourceParam(request.extraQueryParameters))) {
        throw createClientAuthError(misplacedResourceParam, request.correlationId || "");
    }
    if (!request.resource) {
        throw createClientAuthError(resourceParameterRequired, request.correlationId || "");
    }
}
function containsResourceParam(params) {
    if (!params) {
        return false;
    }
    return Object.prototype.hasOwnProperty.call(params, "resource");
}

export { enforceResourceParameter };
//# sourceMappingURL=BaseAuthRequest.mjs.map
