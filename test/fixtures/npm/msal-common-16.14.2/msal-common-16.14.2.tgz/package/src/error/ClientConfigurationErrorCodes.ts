/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

export const redirectUriEmpty = "redirect_uri_empty";
export const claimsRequestParsingError = "claims_request_parsing_error";
export const authorityUriInsecure = "authority_uri_insecure";
export const urlParseError = "url_parse_error";
export const urlEmptyError = "empty_url_error";
export const emptyInputScopesError = "empty_input_scopes_error";
export const invalidClaims = "invalid_claims";
export const tokenRequestEmpty = "token_request_empty";
export const logoutRequestEmpty = "logout_request_empty";
export const invalidCodeChallengeMethod = "invalid_code_challenge_method";
export const pkceParamsMissing = "pkce_params_missing";
export const invalidCloudDiscoveryMetadata = "invalid_cloud_discovery_metadata";
export const invalidAuthorityMetadata = "invalid_authority_metadata";
export const untrustedAuthority = "untrusted_authority";
export const missingSshJwk = "missing_ssh_jwk";
export const missingSshKid = "missing_ssh_kid";
export const unsupportedAuthenticationScheme =
    "unsupported_authentication_scheme";
export const missingNonceAuthenticationHeader =
    "missing_nonce_authentication_header";
export const invalidAuthenticationHeader = "invalid_authentication_header";
export const cannotSetOIDCOptions = "cannot_set_OIDCOptions";
export const cannotAllowPlatformBroker = "cannot_allow_platform_broker";
export const authorityMismatch = "authority_mismatch";
export const invalidRequestMethodForEAR = "invalid_request_method_for_EAR";
export const invalidPlatformBrokerConfiguration =
    "invalid_platform_broker_configuration";
export const issuerValidationFailed = "issuer_validation_failed";
export const invalidResponseMode = "invalid_response_mode";
export const invalidDpopHtm = "invalid_dpop_htm";
export const invalidDpopHtu = "invalid_dpop_htu";
export const invalidDpopNonce = "invalid_dpop_nonce";
export const dpopMissingResourceContext = "dpop_missing_resource_context";
