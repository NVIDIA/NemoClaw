import { TokenClaims } from "../account/TokenClaims.js";
import { Authority } from "../authority/Authority.js";
import { CacheManager } from "../cache/CacheManager.js";
import { AccountEntity } from "../cache/entities/AccountEntity.js";
import { CacheRecord } from "../cache/entities/CacheRecord.js";
import { ICachePlugin } from "../cache/interface/ICachePlugin.js";
import { ISerializableTokenCache } from "../cache/interface/ISerializableTokenCache.js";
import { ICrypto } from "../crypto/ICrypto.js";
import { ITokenBindingKeyManager } from "../crypto/ITokenBindingKeyManager.js";
import { Logger } from "../logger/Logger.js";
import { BaseAuthRequest } from "../request/BaseAuthRequest.js";
import { IPerformanceClient } from "../telemetry/performance/IPerformanceClient.js";
import { RequestStateObject } from "../utils/StateTypes.js";
import { AuthenticationResult } from "./AuthenticationResult.js";
import { AuthorizationCodePayload } from "./AuthorizationCodePayload.js";
import { ServerAuthorizationTokenResponse } from "./ServerAuthorizationTokenResponse.js";
/** @internal */
export type GenerateAuthenticationResultOptions = {
    idTokenClaims?: TokenClaims;
    requestState?: RequestStateObject;
    serverTokenResponse?: ServerAuthorizationTokenResponse;
    requestId?: string;
    tokenBindingKeyManager?: ITokenBindingKeyManager;
};
/**
 * Class that handles response parsing.
 * @internal
 */
export declare class ResponseHandler {
    private clientId;
    private cacheStorage;
    private cryptoObj;
    private tokenBindingKeyManager;
    private logger;
    private homeAccountIdentifier;
    private performanceClient;
    private serializableCache;
    private persistencePlugin;
    constructor(clientId: string, cacheStorage: CacheManager, cryptoObj: ICrypto, logger: Logger, performanceClient: IPerformanceClient, serializableCache: ISerializableTokenCache | null, persistencePlugin: ICachePlugin | null, tokenBindingKeyManager?: ITokenBindingKeyManager);
    /**
     * Function which validates server authorization token response.
     * @param serverResponse
     * @param correlationId
     * @param refreshAccessToken
     */
    validateTokenResponse(serverResponse: ServerAuthorizationTokenResponse, correlationId: string, refreshAccessToken?: boolean): void;
    /**
     * Returns a constructed token response based on given string. Also manages the cache updates and cleanups.
     * @param serverTokenResponse
     * @param authority
     */
    handleServerTokenResponse(serverTokenResponse: ServerAuthorizationTokenResponse, authority: Authority, reqTimestamp: number, request: BaseAuthRequest, apiId: number, authCodePayload?: AuthorizationCodePayload, userAssertionHash?: string, handlingRefreshTokenResponse?: boolean, forceCacheRefreshTokenResponse?: boolean, serverRequestId?: string, additionalCacheKeyComponents?: Record<string, string>): Promise<AuthenticationResult>;
    /**
     * Generates CacheRecord
     * @param serverTokenResponse
     * @param idTokenObj
     * @param authority
     */
    private generateCacheRecord;
    /**
     * Creates an @AuthenticationResult from @CacheRecord , @IdToken , and a boolean that states whether or not the result is from cache.
     *
     * Optionally takes a state string that is set as-is in the response.
     *
     * @param cacheRecord
     * @param idTokenObj
     * @param fromTokenCache
     * @param stateString
     */
    static generateAuthenticationResult(cryptoObj: ICrypto, authority: Authority, cacheRecord: CacheRecord, fromTokenCache: boolean, request: BaseAuthRequest, performanceClient: IPerformanceClient, options?: GenerateAuthenticationResultOptions): Promise<AuthenticationResult>;
}
/** @internal */
export declare function buildAccountToCache(cacheStorage: CacheManager, authority: Authority, homeAccountId: string, base64Decode: (input: string) => string, correlationId: string, idTokenClaims?: TokenClaims, clientInfo?: string, environment?: string, claimsTenantId?: string | null, authCodePayload?: AuthorizationCodePayload, nativeAccountId?: string, logger?: Logger, performanceClient?: IPerformanceClient): AccountEntity;
//# sourceMappingURL=ResponseHandler.d.ts.map