/* eslint-disable header/header */
export const name = "@azure/msal-node";
export const version = "7.1.0";
