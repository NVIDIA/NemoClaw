import { AuthenticationResult, CommonSilentFlowRequest, Logger, NativeRequest } from "@azure/msal-common/node";
/**
 * Prepared silent requests and the acquisition path whose parameters determine their key.
 */
export type SilentRequestKeyInput = {
    requestType: "non-native";
    request: CommonSilentFlowRequest;
    authority: string;
    clientId: string;
} | {
    requestType: "native";
    request: NativeRequest;
};
/**
 * Shares an in-flight silent acquisition while preserving each caller's correlation ID.
 */
export declare function acquireTokenSilentDeduped(owner: object, logger: Logger, silentRequestKey: string, correlationId: string, acquireToken: () => Promise<AuthenticationResult>): Promise<AuthenticationResult>;
/**
 * Builds the key used to identify equivalent in-progress silent requests.
 */
export declare function getSilentRequestKey(input: SilentRequestKeyInput): string;
/**
 * Copies mutable native request values so execution cannot diverge from the stored key.
 */
export declare function snapshotNativeRequest(request: NativeRequest): NativeRequest;
//# sourceMappingURL=SilentRequestCoalescer.d.ts.map