export declare const name = "@azure/msal-node";
export declare const version = "7.1.0";
//# sourceMappingURL=packageMetadata.d.ts.map