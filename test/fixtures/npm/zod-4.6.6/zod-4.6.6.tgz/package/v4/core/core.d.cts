import type * as errors from "./errors.cjs";
import type * as schemas from "./schemas.cjs";
import type { Class, ProtoOf } from "./util.cjs";
type ZodTrait = {
    _zod: {
        def: any;
        [k: string]: any;
    };
};
export interface $constructor<T extends ZodTrait, D = T["_zod"]["def"]> {
    new (def: D): T;
    init(inst: T, def: D): asserts inst is T;
}
export interface $constructorParams {
    Parent?: typeof Class;
}
/** A special constant with type `never` */
export declare const NEVER: never;
export declare function $constructor<T extends ZodTrait, D = T["_zod"]["def"]>(name: string, initializer: (inst: T, def: D) => void, 
/** This trait's members, installed once on every prototype that composes it. They cannot be declared in the initializer above: that runs per instance, and the prototype is shared. */
proto?: ProtoOf<T>, params?: $constructorParams): $constructor<T, D>;
export declare const $brand: unique symbol;
export type $brand<T extends string | number | symbol = string | number | symbol> = {
    [$brand]: {
        [k in T]: true;
    };
};
export type $ZodBranded<T extends schemas.SomeType, Brand extends string | number | symbol, Dir extends "in" | "out" | "inout" = "out"> = T & (Dir extends "inout" ? {
    _zod: {
        input: input<T> & $brand<Brand>;
        output: output<T> & $brand<Brand>;
    };
} : Dir extends "in" ? {
    _zod: {
        input: input<T> & $brand<Brand>;
    };
} : {
    _zod: {
        output: output<T> & $brand<Brand>;
    };
});
export type $ZodNarrow<T extends schemas.SomeType, Out> = T & {
    _zod: {
        output: Out;
    };
};
export declare class $ZodAsyncError extends Error {
    constructor();
}
export declare class $ZodEncodeError extends Error {
    constructor(name: string);
}
export type input<T> = T extends {
    _zod: {
        input: any;
    };
} ? T["_zod"]["input"] : unknown;
export type output<T> = T extends {
    _zod: {
        output: any;
    };
} ? T["_zod"]["output"] : unknown;
export type { output as infer };
export interface $ZodConfig {
    /** Custom error map. Overrides `config().localeError`. */
    customError?: errors.$ZodErrorMap | undefined;
    /** Localized error map. Lowest priority. */
    localeError?: errors.$ZodErrorMap | undefined;
    /** Disable JIT schema compilation. Useful in environments that disallow `eval`. */
    jitless?: boolean | undefined;
    /** Enables parsing input that contains reference cycles. Read when a schema is constructed. */
    memoizer?: schemas.$ZodMemoizer | undefined;
    /**
     * Internal: post-processor invoked on every freshly-constructed schema
     * instance, after init and deferred fns run. Set by `import "zod/compile"`
     * to install AOT compilation. Not part of the public API.
     * @internal
     */
    postProcessor?: ((inst: any) => void) | undefined;
}
export declare const globalConfig: $ZodConfig;
export declare function config(newConfig?: Partial<$ZodConfig>): $ZodConfig;
